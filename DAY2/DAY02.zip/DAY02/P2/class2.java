package P2;

public class class2{
	public void display(){
		System.out.println("Hi from class2 in package P2");
	}
}