package P2;

public class Class3{
	public void display(){
		System.out.println("Hi from Class3 in package P2");
	}
}