package P1;

public class MyClass{
	public void display(){
		System.out.println("Hi From MyClass in package P1");
	}
}
