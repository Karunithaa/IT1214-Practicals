package P1.P3;

public class Class4{
	public void display(){
		System.out.println("Hi from Class4 in package P1.P3");
	}
}