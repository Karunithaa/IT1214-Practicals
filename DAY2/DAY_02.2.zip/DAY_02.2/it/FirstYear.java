package it;

public class FirstYear{
	public void display(){
		System.out.println("Hi From FirstYear in package IT");
	}
}
