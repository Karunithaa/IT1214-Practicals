package it.hons;

public class FourthYear{
	public void display(){
		System.out.println("Hi from FourthYear in package it.hons");
	}
}