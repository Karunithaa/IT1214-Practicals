package amc;

public class SecondYear{
	public void display(){
		System.out.println("Hi from SecondYear in package AMC");
	}
}