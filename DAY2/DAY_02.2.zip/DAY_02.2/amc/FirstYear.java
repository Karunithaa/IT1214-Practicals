package amc;

public class FirstYear{
	public void display(){
		System.out.println("Hi from FirstYear in package AMC");
	}
}