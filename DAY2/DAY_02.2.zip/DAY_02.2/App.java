import it.*;
import amc.*;
import it.hons.*;

class App{
	public static void main(String[] ar){
		amc.FirstYear afy=new amc.FirstYear();
		afy.display();
		
		it.FirstYear fy=new it.FirstYear();
		fy.display();
		
		SecondYear sy=new SecondYear();
		sy.display();
		
		FourthYear fo=new FourthYear();
		fo.display();
	}
}